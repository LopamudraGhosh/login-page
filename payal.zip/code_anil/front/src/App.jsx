import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Login from "./components/Login";
import Register from "./components/Register";
import Notes from "./components/Notes";

function App() {
    const isLoggedIn = !!localStorage.getItem("token");

    return (
        <BrowserRouter>
            <Routes>
                <Route path="/" element={isLoggedIn ? <Notes /> : <Navigate to="/login" />} />
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
            </Routes>
        </BrowserRouter>
    );
}

export default App;
