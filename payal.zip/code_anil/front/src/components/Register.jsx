import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function Register() {
    const [form, setForm] = useState({ username: "", password: "" });
    const navigate = useNavigate();

    const handleRegister = async () => {
        try {
            await axios.post("http://localhost:5000/api/auth/register", form);
            navigate("/login");
        } catch (error) {
            console.log(error);

        }
    };

    return (
        <div className="p-4 max-w-md mx-auto">
            <h2 className="text-2xl mb-4">Register</h2>
            <input className="border p-2 w-full mb-2" placeholder="Username" onChange={e => setForm({ ...form, username: e.target.value })} />
            <input className="border p-2 w-full mb-2" placeholder="Password" type="password" onChange={e => setForm({ ...form, password: e.target.value })} />
            <button className="bg-green-500 text-white px-4 py-2" onClick={handleRegister}>Register</button>
        </div>
    );
}

export default Register;
