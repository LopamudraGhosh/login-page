import { useEffect, useState } from "react";
import axios from "axios";

function Notes() {
    const [notes, setNotes] = useState([]);
    const [newNote, setNewNote] = useState({ title: "", content: "", tag: "" });

    const fetchNotes = async () => {
        const res = await axios.get("http://localhost:5000/api/notes", {
            headers: { Authorization: `Bearer ${localStorage.getItem("token")}` }
        });
        setNotes(res.data);
    };

    const addNote = async () => {
        await axios.post("http://localhost:5000/api/notes", newNote, {
            headers: { Authorization: `Bearer ${localStorage.getItem("token")}` }
        });
        setNewNote({ title: "", content: "", tag: "" });
        fetchNotes();
    };

    const deleteNote = async (id) => {
        await axios.delete(`http://localhost:5000/api/notes/${id}`, {
            headers: { Authorization: `Bearer ${localStorage.getItem("token")}` }
        });
        fetchNotes();
    };

    useEffect(() => {
        fetchNotes();
    }, []);

    return (
        <div className="p-4 max-w-2xl mx-auto">
            <h2 className="text-xl mb-2">My Notes</h2>
            <input placeholder="Title" className="border p-2 w-full mb-2" value={newNote.title} onChange={e => setNewNote({ ...newNote, title: e.target.value })} />
            <textarea placeholder="Content" className="border p-2 w-full mb-2" value={newNote.content} onChange={e => setNewNote({ ...newNote, content: e.target.value })} />
            <input placeholder="Tag" className="border p-2 w-full mb-2" value={newNote.tag} onChange={e => setNewNote({ ...newNote, tag: e.target.value })} />
            <button className="bg-blue-500 text-white px-4 py-2 mb-4" onClick={addNote}>Add Note</button>

            <ul>
                {notes.map(note => (
                    <li key={note._id} className="mb-4 border p-4">
                        <h3 className="font-bold">{note.title}</h3>
                        <p>{note.content}</p>
                        <small className="text-gray-500">#{note.tag}</small>
                        <button className="bg-red-500 text-white px-2 py-1 mt-2" onClick={() => deleteNote(note._id)}>Delete</button>
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default Notes;
