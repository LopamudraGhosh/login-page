const express = require("express");
const {
  getNotes,
  createNote,
  updateNote,
  deleteNote
} = require("../controllers/notesController");
const verifyToken = require("../middleware/authMiddleware");
const router = express.Router();

router.use(verifyToken);
router.get("/", getNotes);
router.post("/", createNote);
router.put("/:id", updateNote);
router.delete("/:id", deleteNote);

module.exports = router;
